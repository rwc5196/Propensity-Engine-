# 🎯 Propensity Scoring Engine

**AI-Powered Sales Intelligence for Light Industrial Staffing**

This system predicts which companies need staffing services *before* they post job listings by analyzing 7 data signals and calculating a propensity score (0-100).

---

## 🚀 Quick Start (5 minutes)

```bash
# 1. Clone and enter directory
cd propensity_engine

# 2. Install dependencies
pip install -r requirements.txt

# 3. Copy environment template and fill in your keys
cp config/.env.example .env
# Edit .env with your API keys

# 4. Set up database
python scripts/setup_database.py

# 5. Run all pipelines
python scripts/run_all_pipelines.py
```

📖 **For detailed setup instructions, see:** `docs/STEP_BY_STEP_GUIDE.md`

---

## 📊 How It Works

### The 7 Signals

| # | Pipeline | Signal Type | Data Source | What It Tells Us |
|---|----------|------------|-------------|------------------|
| 1 | Permits | Expansion | Socrata API | Company is physically growing |
| 2 | WARN | Distress | State websites | Competitor is failing |
| 3 | Macro | Timing | FRED API | Economy favors hiring |
| 4 | Glassdoor | Sentiment | Web scraping | Employees are unhappy |
| 5 | Jobs | Velocity | JobSpy | High turnover/demand |
| 6 | Inventory | Throughput | SEC EDGAR | Goods moving fast |
| 7 | Labor | Tightness | BLS API | Hard to self-recruit |

### Scoring Formula

```
Base Score = (Expansion × 0.25) + (Distress × 0.20) + (Jobs × 0.20) + 
             (Sentiment × 0.15) + (Market × 0.10)

Final Score = Base Score × Macro Modifier

Tier:
  🔥 Hot (75-100):  Contact immediately
  👍 Warm (50-74):  Add to outreach
  🤔 Cool (25-49):  Monitor
  ❄️ Cold (0-24):   Not ready
```

---

## 📁 Project Structure

```
propensity_engine/
├── config/
│   ├── .env.example      # Environment template
│   └── settings.py       # Configuration management
│
├── database/
│   ├── schema.sql        # Supabase table definitions
│   └── connection.py     # Database connection helper
│
├── pipelines/            # 🔧 7 Data Collection Microservices
│   ├── pipeline_1_permits.py     # Building permits (Socrata)
│   ├── pipeline_2_warn.py        # WARN notices
│   ├── pipeline_3_macro.py       # Economic data (FRED)
│   ├── pipeline_4_glassdoor.py   # Employee sentiment
│   ├── pipeline_5_jobs.py        # Job postings (JobSpy)
│   ├── pipeline_6_inventory.py   # SEC inventory data
│   └── pipeline_7_labor.py       # Unemployment (BLS)
│
├── orchestration/        # 🤖 AI & Scoring
│   ├── scoring_engine.py # Calculates propensity scores
│   └── sales_agent.py    # AI email generation (Gemini)
│
├── scripts/              # 🚀 Utilities
│   ├── run_all_pipelines.py    # Master runner
│   └── setup_database.py       # DB initialization
│
├── docs/
│   └── STEP_BY_STEP_GUIDE.md   # Detailed setup guide
│
└── requirements.txt
```

---

## ⚙️ Configuration

### Required API Keys

| Service | Purpose | Get Key |
|---------|---------|---------|
| **Supabase** | Database | https://supabase.com |
| **Google Gemini** | AI Generation | https://aistudio.google.com |
| **FRED** | Economic Data | https://fred.stlouisfed.org/docs/api/api_key.html |

### Optional (but recommended)

| Service | Purpose | Get Key |
|---------|---------|---------|
| BLS | Higher rate limits | https://data.bls.gov/registrationEngine/ |
| Socrata | Higher rate limits | https://data.cityofnewyork.us/profile |

### Environment Variables

```bash
# Required
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
GEMINI_API_KEY=AIzaSy...
FRED_API_KEY=...

# Target Geography (DFW default)
TARGET_CITIES=Dallas,Fort Worth,Arlington,Irving,Plano
TARGET_STATE=TX

# Scoring Weights (must sum to 1.0)
WEIGHT_EXPANSION=0.25
WEIGHT_DISTRESS=0.20
WEIGHT_JOB_VELOCITY=0.20
WEIGHT_SENTIMENT=0.15
WEIGHT_MARKET_TIGHTNESS=0.10
WEIGHT_MACRO=0.10
```

---

## 🔧 Usage

### Run Individual Pipelines

```bash
# Test each pipeline independently
python -m pipelines.pipeline_1_permits
python -m pipelines.pipeline_2_warn
python -m pipelines.pipeline_3_macro
python -m pipelines.pipeline_4_glassdoor
python -m pipelines.pipeline_5_jobs
python -m pipelines.pipeline_6_inventory
python -m pipelines.pipeline_7_labor
```

### Run Everything

```bash
# Full pipeline run
python scripts/run_all_pipelines.py

# With options
python scripts/run_all_pipelines.py --skip-glassdoor --generate-emails --verbose
```

### Programmatic Usage

```python
from pipelines import PermitPipeline, run_all_pipelines
from orchestration.scoring_engine import ScoringEngine
from orchestration.sales_agent import SalesAgent

# Run single pipeline
permits = PermitPipeline()
results = permits.run()

# Score companies
engine = ScoringEngine()
hot_leads = engine.get_hot_leads(min_score=75)

# Generate outreach
agent = SalesAgent()
email = agent.generate_outreach(
    company_name="Acme Logistics",
    signals={"expansion_score": 85, "job_velocity_score": 70}
)
```

---

## 🚀 Deployment

### Option A: Railway (Recommended)

1. Push to GitHub
2. Connect to [Railway](https://railway.app)
3. Add environment variables
4. Deploy

### Option B: GitHub Actions (Free)

See `.github/workflows/daily_run.yml` for automated daily execution.

### Option C: Docker

```bash
docker build -t propensity-engine .
docker run --env-file .env propensity-engine
```

---

## 💰 Cost Breakdown

| Component | Monthly Cost |
|-----------|-------------|
| Supabase (Free tier) | $0 |
| Gemini API (Free tier) | $0 |
| FRED API | Free |
| BLS API | Free |
| SEC EDGAR | Free |
| **Railway (optional)** | ~$5 |
| **Total** | **$0-5/mo** |

---

## 📈 Scaling to Production

To expand beyond DFW:

1. **Add cities** in `config/settings.py` → `SOCRATA_ENDPOINTS`
2. **Add states** in `config/settings.py` → `WARN_STATES`
3. **Update zips** in `.env` → `TARGET_ZIPS`
4. **Scale database** to Supabase Pro ($25/mo)

For high-volume scraping, consider:
- ZenRows ($29/mo) for Glassdoor
- Proxycurl ($49/mo) for LinkedIn

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` |
| `Connection refused` | Check SUPABASE_URL and SUPABASE_KEY |
| `Rate limit exceeded` | Wait 1 hour, or add API key |
| No data returned | Expand date range or zip codes |

---

## 📝 License

MIT License - See LICENSE file

---

## 🙏 Acknowledgments

- [Socrata Open Data](https://dev.socrata.com/) for permit data
- [FRED](https://fred.stlouisfed.org/) for economic indicators
- [JobSpy](https://github.com/Bunsly/JobSpy) for job scraping
- [Google Gemini](https://ai.google.dev/) for AI generation

---

Built for the light industrial staffing industry 🏭
